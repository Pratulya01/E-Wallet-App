package org.UserService.model.enums;

public enum UserStatus {
    ACTIVE, INACTIVE, BLOCKED
}
