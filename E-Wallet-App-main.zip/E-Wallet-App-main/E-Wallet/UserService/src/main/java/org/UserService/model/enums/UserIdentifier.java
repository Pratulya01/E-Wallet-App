package org.UserService.model.enums;

public enum UserIdentifier {
    PAN, AADHAAR, VOTER_ID;
}
