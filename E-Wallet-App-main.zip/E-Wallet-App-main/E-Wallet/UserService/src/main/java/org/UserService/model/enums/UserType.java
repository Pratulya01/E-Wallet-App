package org.UserService.model.enums;

public enum UserType {
    USER,ADMIN;
}
