package org.TxnService.model;

public enum TxnStatus {
    INITIATED,FAILED,SUCCESS,PENDING;
}
