package models.enums;

public enum UserIdentifier {
    PAN, AADHAAR, VOTER_ID;
}
